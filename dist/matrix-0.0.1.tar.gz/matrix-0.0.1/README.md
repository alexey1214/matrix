# Matrix

This small package provides a function get_matrix, which retrieves a square matrix (NxN) from a remote server, traverses it in a spiral, starting from the upper-left corner, and returns it to the user as a List[int].

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install matrix.

```bash
pip install 
```